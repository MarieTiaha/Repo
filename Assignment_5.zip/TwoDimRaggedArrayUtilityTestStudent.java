/*
 * Class: CMSC203 
 * Instructor: Farnaz Eivazi
 * Description: (The TwoDimRaggedArrayUtilityTestStudent class comprises JUnit test methods validating
 *  the functionality of the TwoDimRaggedArrayUtility class across diverse scenarios, including file I/O, 
 *  array calculations, and edge cases. Utilizing assertions, 
 * these tests confirm the accuracy and robustness of the utility methods under various conditions./ klm)
 * Due: 11/10/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: __Marie Jeanne Choualeu Tiaha________
*/

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;

import org.junit.Test;

public class TwoDimRaggedArrayUtilityTestStudent {

    @Test
    public void testReadFile() {
        File file = new File("testInput.txt");

        double[][] expectedArray = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        try {
            double[][] actualArray = TwoDimRaggedArrayUtility.readFile(file);

            assertEquals(expectedArray.length, actualArray.length);

            for (int i = 0; i < expectedArray.length; i++) {
                assertEquals(expectedArray[i].length, actualArray[i].length);

                for (int j = 0; j < expectedArray[i].length; j++) {
                    assertEquals(expectedArray[i][j], actualArray[i][j], 0.001);
                }
            }

        } catch (FileNotFoundException e) {
            assertTrue("File not found", false);
        }
    }

    @Test
    public void testWriteToFile() {
        File inputFile = new File("testInput.txt");
        File outputFile = new File("testOutput.txt");

        try {
            double[][] array = TwoDimRaggedArrayUtility.readFile(inputFile);
            TwoDimRaggedArrayUtility.writeToFile(array, outputFile);

            File expectedFile = new File("expectedOutput.txt");
            double[][] expectedArray = TwoDimRaggedArrayUtility.readFile(expectedFile);

            double[][] actualArray = TwoDimRaggedArrayUtility.readFile(outputFile);

            assertEquals(expectedArray.length, actualArray.length);

            for (int i = 0; i < expectedArray.length; i++) {
                assertEquals(expectedArray[i].length, actualArray[i].length);

                for (int j = 0; j < expectedArray[i].length; j++) {
                    assertEquals(expectedArray[i][j], actualArray[i][j], 0.001);
                }
            }

        } catch (FileNotFoundException e) {
            assertTrue("File not found", false);
        }
    }

    @Test
    public void testGetTotal() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        double expectedTotal = 36.0;
        double actualTotal = TwoDimRaggedArrayUtility.getTotal(array);

        assertEquals(expectedTotal, actualTotal, 0.001);
    }
    @Test
    public void testGetAverage() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        double expectedAverage = 4.0;
        double actualAverage = TwoDimRaggedArrayUtility.getAverage(array);

        assertEquals(expectedAverage, actualAverage, 0.001);
    }

    @Test
    public void testGetRowTotal() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int rowIndex = 1;
        double expectedRowTotal = 9.0;
        double actualRowTotal = TwoDimRaggedArrayUtility.getRowTotal(array, rowIndex);

        assertEquals(expectedRowTotal, actualRowTotal, 0.001);
    }

    @Test
    public void testGetColumnTotal() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int columnIndex = 1;
        double expectedColumnTotal = 14.0;
        double actualColumnTotal = TwoDimRaggedArrayUtility.getColumnTotal(array, columnIndex);

        assertEquals(expectedColumnTotal, actualColumnTotal, 0.001);
    }
    @Test
    public void testGetHighestInRow() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int rowIndex = 2;
        double expectedHighestInRow = 8.0;
        double actualHighestInRow = TwoDimRaggedArrayUtility.getHighestInRow(array, rowIndex);

        assertEquals(expectedHighestInRow, actualHighestInRow, 0.001);
    }

    @Test
    public void testGetLowestInRow() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int rowIndex = 0;
        double expectedLowestInRow = 1.0;
        double actualLowestInRow = TwoDimRaggedArrayUtility.getLowestInRow(array, rowIndex);

        assertEquals(expectedLowestInRow, actualLowestInRow, 0.001);
    }

    @Test
    public void testGetHighestInColumn() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int columnIndex = 2;
        double expectedHighestInColumn = 8.0;
        double actualHighestInColumn = TwoDimRaggedArrayUtility.getHighestInColumn(array, columnIndex);

        assertEquals(expectedHighestInColumn, actualHighestInColumn, 0.001);
    }

    @Test
    public void testGetLowestInColumn() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int columnIndex = 0;
        double expectedLowestInColumn = 1.0;
        double actualLowestInColumn = TwoDimRaggedArrayUtility.getLowestInColumn(array, columnIndex);

        assertEquals(expectedLowestInColumn, actualLowestInColumn, 0.001);
    }

    @Test
    public void testGetHighestInArray() {
        double[][] array = {
                {1.0, 2.0, 3.0},
                {4.0, 5.0},
                {6.0, 7.0, 8.0}
        };

        double expectedHighestInArray = 8.0;
        double actualHighestInArray = TwoDimRaggedArrayUtility.getHighestInArray(array);

        assertEquals(expectedHighestInArray, actualHighestInArray, 0.001);
    }

    @Test
    public void testGetLowestInArray() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        double expectedLowestInArray = 1.0;
        double actualLowestInArray = TwoDimRaggedArrayUtility.getLowestInArray(array);

        assertEquals(expectedLowestInArray, actualLowestInArray, 0.001);
    }

    

    @Test
    public void testGetHighestInColumnIndex() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int columnIndex = 2;
        int expectedHighestInColumnIndex = 2;
        int actualHighestInColumnIndex = TwoDimRaggedArrayUtility.getHighestInColumnIndex(array, columnIndex);

        assertEquals(expectedHighestInColumnIndex, actualHighestInColumnIndex);
    }

    @Test
    public void testGetLowestInColumnIndex() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 5.0 },
                { 6.0, 7.0, 8.0 }
        };

        int columnIndex = 0;
        int expectedLowestInColumnIndex = 0;
        int actualLowestInColumnIndex = TwoDimRaggedArrayUtility.getLowestInColumnIndex(array, columnIndex);

        assertEquals(expectedLowestInColumnIndex, actualLowestInColumnIndex);
    }
    
    @Test
    public void testGetHighestInRowIndex() {
        double[][] array = {
                { 1.0, 2.0, 3.0 },
                { 4.0, 8.0, 6.0 },
                { 7.0, 5.0, 9.0 }
        };

        int rowIndex = 1; // Index of the row to test
        int expectedHighestIndex = 1; // Index of the highest element in the row

        int actualHighestIndex = TwoDimRaggedArrayUtility.getHighestInRowIndex(array, rowIndex);

        assertEquals(expectedHighestIndex, actualHighestIndex);
    }
    
    @Test
    public void testGetLowestInRowIndex() {
        double[][] array = {
                { 5.0, 2.0, 3.0 },
                { 4.0, 1.0, 6.0 },
                { 7.0, 8.0, 9.0 }
        };

        int rowIndex = 1; // Index of the row to test
        int expectedLowestIndex = 1; // Index of the lowest element in the row

        int actualLowestIndex = TwoDimRaggedArrayUtility.getLowestInRowIndex(array, rowIndex);

        assertEquals(expectedLowestIndex, actualLowestIndex);
    }
}
