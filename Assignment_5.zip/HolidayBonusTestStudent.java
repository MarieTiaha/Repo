/*
 * Class: CMSC203 
 * Instructor: Farnaz Eivazi
 * Description: (The HolidayBonusTestStudent class contains JUnit tests for the HolidayBonus utility class. 
 * The testCalculateHolidayBonus method verifies that the calculated bonuses for each store match the expected 
 * values based on the provided sales data. The testCalculateTotalHolidayBonus method checks if the total holiday 
 * bonus for the entire district matches the expected value. These tests help ensure the accuracy of the 
 * calculateHolidayBonus and calculateTotalHolidayBonus methods in the HolidayBonus class, providing a robust 
 * testing suite for evaluating their functionality..)
 * Due: 11/10/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: __Marie Jeanne Choualeu Tiaha________
*/
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class HolidayBonusTestStudent {

    @Test
    public void testCalculateHolidayBonus() {
        double[][] sales = {
                { 100.0, 150.0, 200.0 },
                { 120.0, 80.0 },
                { 90.0, 110.0, 95.0 }
        };

        double[] expectedBonuses = { 5000.0, 1000.0, 2000.0};

        double[] actualBonuses = HolidayBonus.calculateHolidayBonus(sales);

        assertEquals(expectedBonuses.length, actualBonuses.length);

        for (int i = 0; i < expectedBonuses.length; i++) {
            assertEquals(expectedBonuses[i], actualBonuses[i], 0.001);
        }
    }

    @Test
    public void testCalculateTotalHolidayBonus() {
        double[][] sales = {
                { 100.0, 150.0, 200.0 },
                { 120.0, 80.0 },
                { 90.0, 110.0, 95.0 }
        };

        double expectedTotalBonus = 8000.0; 

        double actualTotalBonus = HolidayBonus.calculateTotalHolidayBonus(sales);

        assertEquals(expectedTotalBonus, actualTotalBonus, 0.001);
    }
}