/*
 * Class: CMSC203 
 * Instructor: Farnaz Eivazi
 * Description: (The TwoDimRaggedArrayUtility class provides utility methods for working with two-dimensional
 *  ragged arrays of doubles. It includes functions to read and write such arrays from/to files, calculate the 
 *  total and average of array elements, determine the total of a specific row or column, and find the highest
 *   and lowest values in rows, columns, and the entire array. Additionally, the class handles edge cases, such 
 *   as invalid indices or empty rows, with appropriate exceptions.
 *  The main method demonstrates the usage of file input/output operations with the utility methods.)
 * Due: 11/10/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: __Marie Jeanne Choualeu Tiaha________
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This utility class works with two-dimensional ragged arrays with a maximum of 10 rows and 10 columns.
 * It supports negative and positive numbers.
 */
public final class TwoDimRaggedArrayUtility {

    private TwoDimRaggedArrayUtility() {
        // Private constructor to prevent instantiation
    }

    /**
     * Reads from a file and returns a two-dimensional ragged array of doubles.
     * The maximum rows is 10, and the maximum columns for each row is 10.
     * Each row in the file is separated by a new line, and each element in the row is separated by a space.
     *
     * @param file the file to read from
     * @return a two-dimensional ragged (depending on data) array of doubles if the file is not empty,
     *         returns null if the file is empty
     * @throws FileNotFoundException if the specified file is not found
     */
    public static double[][] readFile(File file) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);

        // Read the file and create a ragged array
        int rows = 0;
        while (scanner.hasNextLine() && rows < 10) {
            rows++;
            scanner.nextLine();
        }

        double[][] raggedArray = new double[rows][];
        scanner.close();

        scanner = new Scanner(file);
        for (int i = 0; i < rows; i++) {
            String[] rowElements = scanner.nextLine().split(" ");
            raggedArray[i] = new double[rowElements.length];

            for (int j = 0; j < rowElements.length; j++) {
                raggedArray[i][j] = Double.parseDouble(rowElements[j]);
            }
        }

        scanner.close();
        return raggedArray;
    }

    /**
     * Writes the ragged array of doubles into the file.
     * Each row is on a separate line within the file, and each double is separated by a space.
     *
     * @param data       two-dimensional ragged array of doubles
     * @param outputFile the file to write to
     * @throws FileNotFoundException if the specified output file is not valid
     */
    public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException {
        try (java.io.PrintWriter output = new java.io.PrintWriter(outputFile)) {
            for (double[] row : data) {
                for (double value : row) {
                    output.print(value + " ");
                }
                output.println();
            }
        }
    }

    /**
     * Returns the total of all the elements of the two-dimensional array.
     *
     * @param data the two-dimensional array to get the total of
     * @return the sum of all the elements in the two-dimensional array
     */
    public static double getTotal(double[][] data) {
        double total = 0.0;
        for (double[] row : data) {
            for (double value : row) {
                total += value;
            }
        }
        return total;
    }

    /**
     * Returns the average of the elements in the two-dimensional array.
     *
     * @param data the two-dimensional array to get the average of
     * @return the average of the elements in the two-dimensional array (total of elements / number of elements)
     */
    public static double getAverage(double[][] data) {
        int totalElements = 0;
        double sum = 0.0;

        for (double[] row : data) {
            totalElements += row.length;
            for (double value : row) {
                sum += value;
            }
        }

        return totalElements > 0 ? sum / totalElements : 0.0;
    }

    /**
     * Returns the total of the selected row in the two-dimensional array. Row index 0 is the first row.
     *
     * @param data the two-dimensional array
     * @param row  the row index to take the total of (0 refers to the first row)
     * @return the total of the row
     */
    public static double getRowTotal(double[][] data, int row) {
        double total = 0.0;
        if (row >= 0 && row < data.length) {
            for (double value : data[row]) {
                total += value;
            }
        }
        return total;
    }

    /**
     * Returns the total of the selected column in the two-dimensional array. Column index 0 is the first column.
     * If a row doesn’t contain that column, it is not an error, that row will not participate in this method.
     *
     * @param data the two-dimensional array
     * @param col  the column index to take the total of (0 refers to the first column)
     * @return the total of the column
     */
    public static double getColumnTotal(double[][] data, int col) {
        double total = 0.0;
        for (double[] row : data) {
            if (col >= 0 && col < row.length) {
                total += row[col];
            }
        }
        return total;
    }

    /**
     * Returns the largest element in the selected row in the two-dimensional array. Row index 0 is the first row.
     *
     * @param data the two-dimensional array
     * @param row  the row index to find the largest element of (0 refers to the first row)
     * @return the largest element of the row
     */
    public static double getHighestInRow(double[][] data, int row) {
        double highest = Double.NEGATIVE_INFINITY;
        if (row >= 0 && row < data.length) {
            for (double value : data[row]) {
                if (value > highest) {
                    highest = value;
                }
            }
        }
        return highest;
    }

    /**
     * Returns the index of the largest element in the selected row in the two-dimensional array.
     * Row index 0 is the first row.
     *
     * @param data the two-dimensional array
     * @param row  the row index to find the largest element of (0 refers to the first row)
     * @return the index of the largest element of the row
     */
    
    public static int getHighestInRowIndex(double[][] array, int row) {
        int highestIndex = 0;
        double highestValue = array[row][0];

        for (int i = 1; i < array[row].length; i++) {
            if (array[row][i] > highestValue) {
                highestValue = array[row][i];
                highestIndex = i;
            }
        }
        return highestIndex;
    } 
    
    
    

    /**
     * Returns the smallest element in the selected row in the two-dimensional array. Row index 0 is the first row.
     *
     * @param data the two-dimensional array
     * @param row  the row index to find the smallest element of (0 refers to the first row)
     * @return the smallest element of the row
     */
    public static double getLowestInRow(double[][] data, int row) {
        double lowest = Double.POSITIVE_INFINITY;
        if (row >= 0 && row < data.length) {
            for (double value : data[row]) {
                if (value < lowest) {
                    lowest = value;
                }
            }
        }
        return lowest;
    }

    /**
     * Returns the index of the smallest element in the selected row in the two-dimensional array.
     * Row index 0 is the first row.
     *
     * @param data the two-dimensional array
     * @param row  the row index to find the smallest element of (0 refers to the first row)
     * @return the index of the smallest element of the row
     */
    public static int getLowestInRowIndex(double[][] array, int row) {
        int lowestIndex = 0;
        double lowestValue = array[row][0];

        for (int i = 1; i < array[row].length; i++) {
            if (array[row][i] < lowestValue) {
                lowestValue = array[row][i];
                lowestIndex = i;
            }
        }

        return lowestIndex;
    }
    
    

    /**
     * Returns the largest element in the selected column in the two-dimensional array. Column index 0 is the first column.
     * If a row doesn’t contain that column, it is not an error, that row will not participate in this method.
     *
     * @param data the two-dimensional array
     * @param col  the column index to find the largest element of (0 refers to the first column)
     * @return the largest element of the column
     */
    public static double getHighestInColumn(double[][] data, int col) {
        double highest = Double.NEGATIVE_INFINITY;
        for (double[] row : data) {
            if (col >= 0 && col < row.length) {
                highest = Math.max(highest, row[col]);
            }
        }
        return highest;
    }

    /**
     * Returns the index of the largest element in the selected column in the two-dimensional array.
     * Column index 0 is the first column. If a row doesn’t contain that column, it is not an error,
     * that row will not participate in this method.
     *
     * @param data the two-dimensional array
     * @param col  the column index to find the largest element of (0 refers to the first column)
     * @return the index of the largest element of the column
     */
    public static int getHighestInColumnIndex(double[][] data, int col) {
        int highestIndex = -1;
        double highest = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < data.length; i++) {
            if (col >= 0 && col < data[i].length && data[i][col] > highest) {
                highest = data[i][col];
                highestIndex = i;
            }
        }
        return highestIndex;
    }
    

    /**
     * Returns the smallest element in the selected column in the two-dimensional array. Column index 0 is the first column.
     * If a row doesn’t contain that column, it is not an error, that row will not participate in this method.
     *
     * @param data the two-dimensional array
     * @param col  the column index to find the smallest element of (0 refers to the first column)
     * @return the smallest element of the column
     */
    public static double getLowestInColumn(double[][] data, int col) {
        double lowest = Double.POSITIVE_INFINITY;
        for (double[] row : data) {
            if (col >= 0 && col < row.length) {
                lowest = Math.min(lowest, row[col]);
            }
        }
        return lowest;
    }

    /**
     * Returns the index of the smallest element in the selected column in the two-dimensional array.
     * Column index 0 is the first column. If a row doesn’t contain that column, it is not an error,
     * that row will not participate in this method.
     *
     * @param data the two-dimensional array
     * @param col  the column index to find the smallest element of (0 refers to the first column)
     * @return the index of the smallest element of the column
     */
    public static int getLowestInColumnIndex(double[][] data, int col) {
        int lowestIndex = -1;
        double lowest = Double.POSITIVE_INFINITY;
        for (int i = 0; i < data.length; i++) {
            if (col >= 0 && col < data[i].length && data[i][col] < lowest) {
                lowest = data[i][col];
                lowestIndex = i;
            }
        }
        return lowestIndex;
    }

    /**
     * Returns the largest element in the two-dimensional array.
     *
     * @param data the two-dimensional array
     * @return the largest element in the two-dimensional array
     */
    public static double getHighestInArray(double[][] data) {
        double highest = Double.NEGATIVE_INFINITY;
        for (double[] row : data) {
            for (double value : row) {
                highest = Math.max(highest, value);
            }
        }
        return highest;
    }

    /**
     * Returns the smallest element in the two-dimensional array.
     *
     * @param data the two-dimensional array
     * @return the smallest element in the two-dimensional array
     */
    public static double getLowestInArray(double[][] data) {
        double lowest = Double.POSITIVE_INFINITY;
        for (double[] row : data) {
            for (double value : row) {
                lowest = Math.min(lowest, value);
            }
        }
        return lowest;
    }
    
    /**
     * Helper method to print the content of a two-dimensional array.
     *
     * @param array the array to print
     */
    private static void printArray(double[][] array) {
        for (double[] row : array) {
            for (double value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
    
    public static void main(String[] args) throws FileNotFoundException {
        // Example usage of the class
        File inputFile = new File("src/input.txt");
        double[][] dataArray = readFile(inputFile);

        if (dataArray != null) {
            // Print the content of the array
            System.out.println("Original Data Array:");
            printArray(dataArray);

            // Calculate and print the total of all elements
            double total = getTotal(dataArray);
            System.out.println("Total of all elements: " + total);

            // Calculate and print the average of all elements
            double average = getAverage(dataArray);
            System.out.println("Average of all elements: " + average);

            // Calculate and print the total of a specific row (e.g., row 0)
            int selectedRow = 0;
            double rowTotal = getRowTotal(dataArray, selectedRow);
            System.out.println("Total of Row " + selectedRow + ": " + rowTotal);

            // Calculate and print the total of a specific column (e.g., column 1)
            int selectedColumn = 1;
            double columnTotal = getColumnTotal(dataArray, selectedColumn);
            System.out.println("Total of Column " + selectedColumn + ": " + columnTotal);

            // Find and print the highest element in the array
            double highest = getHighestInArray(dataArray);
            System.out.println("Highest element in the array: " + highest);

            // Find and print the lowest element in the array
            double lowest = getLowestInArray(dataArray);
            System.out.println("Lowest element in the array: " + lowest);
        } else {
            System.out.println("The file is empty.");
        }

        File outputFile = new File("output.txt");
        writeToFile(dataArray, outputFile);
    }
}