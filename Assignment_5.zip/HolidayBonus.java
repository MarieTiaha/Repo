/*
 * Class: CMSC203 
 * Instructor: Farnaz Eivazi
 * Description: (The HolidayBonus class is a utility for computing holiday bonuses based on sales data. 
 * It utilizes constants such as HIGHEST_SALES_BONUS and LOWEST_SALES_BONUS to assign bonuses to stores based
 *  on their sales performance. The class encapsulates methods like calculateHolidayBonus and 
 *  calculateTotalHolidayBonus to facilitate the calculation of individual store bonuses and 
 *  the total holiday bonus for an entire district.)
 * Due: 11/10/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: __Marie Jeanne Choualeu Tiaha________
*/

/**
 * The HolidayBonus class calculates holiday bonuses for each store and the total holiday bonuses for the district.
 * It uses constants for bonus amounts and provides methods to perform these calculations.
 */
public class HolidayBonus {

    // Constants for bonus amounts
    private static final double HIGHEST_SALES_BONUS = 5000.0;
    private static final double LOWEST_SALES_BONUS = 1000.0;
    private static final double OTHER_STORES_BONUS = 2000.0;

    /**
     * Calculates holiday bonuses for each store based on their sales performance.
     *
     * @param sales a two-dimensional array representing the sales for each store and each category.
     * @return an array of holiday bonuses for each store.
     */
    public static double[] calculateHolidayBonus(double[][] sales) {
        int numRows = sales.length;
        double[] bonuses = new double[numRows];

        for (int i = 0; i < numRows; i++) {
            int highestIndex = TwoDimRaggedArrayUtility.getHighestInRowIndex(sales, i);
            int lowestIndex = TwoDimRaggedArrayUtility.getLowestInRowIndex(sales, i);
            for(int j = 0; j<sales[i].length; j++) {
            	
            	if (j == highestIndex) {
                    bonuses[i] = bonuses[i]+HIGHEST_SALES_BONUS;
                }
            	if (j == lowestIndex) {
                    bonuses[i] = bonuses[i]+LOWEST_SALES_BONUS;
                } 
            	if(j != lowestIndex && j != highestIndex){
                    bonuses[i] = bonuses[i]+OTHER_STORES_BONUS;
                }
            }
            
            
        }
        
        return bonuses;
    }

    /**
     * Calculates the total holiday bonuses for the entire district based on store sales.
     *
     * @param sales a two-dimensional array representing the sales for each store and each category.
     * @return the total holiday bonuses for the district.
     */
    
    
    public static double calculateTotalHolidayBonus(double[][] sales) {
        double totalBonus = 0.0;
        double[] storeBonuses = calculateHolidayBonus(sales);

        for (double bonus : storeBonuses) {
            totalBonus += bonus;
        }

        return totalBonus;
    }
    
    public static void main(String[] args) 
    {
        // Example usage
        double[][] sales = {
                {100.0, 200.0, 150.0},
                {120.0, 80.0, 90.0, 110.0},
                {300.0, 250.0, 200.0, 180.0}
        };

        double[] storeBonuses = calculateHolidayBonus(sales);
        double totalDistrictBonus = calculateTotalHolidayBonus(sales);

        // Print or use the calculated bonuses
        System.out.println("Individual Store Bonuses:");
        for (int i = 0; i < storeBonuses.length; i++) {
            System.out.println("Store " + i + ": $" + storeBonuses[i]);
        }

        System.out.println("\nTotal District Bonus: $" + totalDistrictBonus);
        
    }
}
           
  