public class Plot 
{
    private int x;
    private int y;
    private int width;
    private int depth;
    
    
    public Plot() {
        // Provide default values or leave them as 0, depending on your requirements
        this.x = 0;
        this.y = 0;
        this.width = 1;
        this.depth = 1;
    }

    // Constructor
    public Plot(int x, int y, int width, int depth) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.depth = depth;
    }

    // Getter and Setter methods for x, y, width, and depth

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    // Method to check if another plot overlaps with the current plot
    public boolean overlaps(Plot other) 
    {
    	int x1 = this.x;
        int y1 = this.y;
        int x2 = x1 + this.width;
        int y2 = y1 + this.depth;

        int x3 = other.x;
        int y3 = other.y;
        int x4 = x3 + other.width;
        int y4 = y3 + other.depth;

        return !(x2 < x3 || x4 < x1 || y2 < y3 || y4 < y1);
    }

    // Method to check if another plot is encompassed by the current plot
    public boolean encompasses(Plot other) 
    {
    	int x1 = this.x;
        int y1 = this.y;
        int x2 = x1 + this.width;
        int y2 = y1 + this.depth;

        int x3 = other.x;
        int y3 = other.y;
        int x4 = x3 + other.width;
        int y4 = y3 + other.depth;

        return x3 >= x1 && y3 >= y1 && x4 <= x2 && y4 <= y2;
    }

    // toString method to represent a Plot instance
    @Override
    public String toString() 
    {
        return x + "," + y + "," + width + "," + depth;
    }
}
