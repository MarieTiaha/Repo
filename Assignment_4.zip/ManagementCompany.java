public class ManagementCompany {
    private String name;
    private String taxId;
    private double feePercentage;
    private Property[] properties;
    private Plot plot;
    private int numberOfProperties;

    // Constants
    static final int MAX_PROPERTY = 5;
    private static final int MGMT_WIDTH = 10;
    private static final int MGMT_DEPTH = 10;
    
    
    
    public String getName() {
        return this.name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for plot
    public Plot getPlot() {
        return this.plot;
    }

    // Setter for plot
    public void setPlot(Plot plot) {
        this.plot = plot;
    }

    // Constructors
    public ManagementCompany(String name, String taxId, double feePercentage) {
        this.name = name;
        this.taxId = taxId;
        this.feePercentage = feePercentage;
        this.properties = new Property[MAX_PROPERTY];
        this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
        this.numberOfProperties = 0;
    }

    // Getter and Setter methods

    // Method to add a property
    public int addProperty(Property property) {
        if (numberOfProperties >= MAX_PROPERTY) {
            return -1; // Array is full
        }

        if (property == null) {
            return -2; // Property is null
        }

        if (!plot.encompasses(property.getPlot())) {
            return -3; // Property plot is not encompassed by management company plot
        }

        for (int i = 0; i < numberOfProperties; i++) {
            if (properties[i].getPlot().overlaps(property.getPlot())) {
                return -4; // Property plot overlaps with another property's plot
            }
        }

        properties[numberOfProperties] = property;
        numberOfProperties++;
        return numberOfProperties - 1; // Return the index where property was added
    }


    // getTotalRent
    public double getTotalRent() {
        double totalRent = 0.0;
        for (int i = 0; i < numberOfProperties; i++) {
            totalRent += properties[i].getRentAmount();
        }
        return totalRent;
    }

    // getHighestRentProperty
    public Property getHighestRentProperty() {
        Property highestRentProperty = null;
        double highestRent = Double.MIN_VALUE;
        for (int i = 0; i < numberOfProperties; i++) {
            if (properties[i].getRentAmount() > highestRent) {
                highestRent = properties[i].getRentAmount();
                highestRentProperty = properties[i];
            }
        }
        return highestRentProperty;
    }

    // removeLastProperty
    public void removeLastProperty() {
        if (numberOfProperties > 0) {
            properties[numberOfProperties - 1] = null;
            numberOfProperties--;
        }
    }

    // isPropertiesFull
    public boolean isPropertiesFull() {
        return numberOfProperties == MAX_PROPERTY;
    }

    // getPropertiesCount
    public int getPropertiesCount() {
        return numberOfProperties;
    }

    // isManagementFeeValid
    public boolean isManagementFeeValid() {
        return feePercentage >= 0 && feePercentage <= 100;
    }

    // toString method
    @Override
    public String toString() {
    	StringBuilder result = new StringBuilder();
        result.append("List of the properties for ").append(name).append(", taxID: ").append(taxId).append("\n")
                .append("______________________________________________________\n");

        for (int i = 0; i < numberOfProperties; i++) {
            result.append(properties[i].toString()).append("\n").append("______________________________________________________\n");
        }

        double totalManagementFee = getTotalRent() * (feePercentage / 100);
        result.append("\n total management Fee: ").append(String.format("%.2f", totalManagementFee));

        return result.toString();
    }
}