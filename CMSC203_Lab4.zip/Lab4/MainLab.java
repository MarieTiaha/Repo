import javax.swing.JFrame;

public class MainLab {
	public static void main( String [] args )
    {
		TwoDimArrayPractice app = new TwoDimArrayPractice( );
		app.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    }

}
