/**
 * This class represents an alcoholic beverage.
 *
 * <p>
 * The Alcohol class extends the Beverage class and adds functionality specific to alcoholic beverages.
 * It includes information about whether the beverage is offered during the weekend and calculates the
 * price based on its size and weekend offering.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public class Alcohol extends Beverage {

    private static final double WEEKEND_COST = 0.6;

    private boolean offeredInWeekend;

    /**
     * Constructs an Alcohol object with the specified name, size, and weekend offering.
     *
     * @param name              the name of the alcoholic beverage
     * @param size              the size of the beverage (SMALL, MEDIUM, LARGE)
     * @param offeredInWeekend true if the beverage is offered during the weekend, false otherwise
     */
    public Alcohol(String name, Size size, boolean offeredInWeekend) {
        super(name, Type.ALCOHOL, size);
        this.offeredInWeekend = offeredInWeekend;
    }

    /**
     * Copy constructor for creating a deep copy of another Alcohol object.
     *
     * @param otherAlcohol the Alcohol object to copy
     */
    public Alcohol(Alcohol otherAlcohol) {
        super(otherAlcohol);
        this.offeredInWeekend = otherAlcohol.offeredInWeekend;
    }


	/**
     * Calculates the price of the alcoholic beverage based on its size, base price, and weekend offering.
     *
     * @return the calculated price of the alcoholic beverage
     */
    @Override
    public double calcPrice() {
        double price = getBasePrice() + (getSize().ordinal() * getSizePrice());
        if (offeredInWeekend) {
            price += WEEKEND_COST;
        }

        return price;
    }

    /**
     * Checks if two Alcohol objects are equal.
     *
     * @param obj the object to compare
     * @return true if the objects are equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;

        Alcohol alcohol = (Alcohol) obj;

        return offeredInWeekend == alcohol.offeredInWeekend;
    }

    /**
     * Returns a string representation of the Alcohol object.
     *
     * @return a string representation of the object
     */
    @Override
    public String toString() {
        return "Alcohol{" +
                "name='" + getName() + '\'' +
                ", size=" + getSize() +
                ", offeredInWeekend=" + offeredInWeekend +
                ", price=$" + calcPrice() +
                '}';
    }

    /**
     * Gets the weekend offering status of the alcoholic beverage.
     *
     * @return true if the beverage is offered during the weekend, false otherwise
     */
    public boolean isOfferedInWeekend() {
        return offeredInWeekend;
    }

    /**
     * Sets the weekend offering status of the alcoholic beverage.
     *
     * @param offeredInWeekend true if the beverage is offered during the weekend, false otherwise
     */
    public void setOfferedInWeekend(boolean offeredInWeekend) {
        this.offeredInWeekend = offeredInWeekend;
    }
}