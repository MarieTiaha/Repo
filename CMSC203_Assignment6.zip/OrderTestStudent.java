import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OrderTestStudent {

    @Test
    public void testIsWeekend() {
        Order orderWeekend = new Order(1, Day.SATURDAY, new Customer("John Doe", 25));
        assertTrue(orderWeekend.isWeekend());

        Order orderWeekday = new Order(2, Day.WEDNESDAY, new Customer("Alice Smith", 30));
        assertFalse(orderWeekday.isWeekend());
    }

    @Test
    public void testGetBeverage() {
        Order order = new Order(3, Day.MONDAY, new Customer("Bob Johnson", 28));

        // Assuming Coffee, Smoothie, and Alcohol are subclasses of Beverage
        order.addNewBeverage("Latte", Size.MEDIUM, true, false);
        order.addNewBeverage("Fruit Punch", Size.SMALL, 3, true);
        order.addNewBeverage("Whiskey Sour", Size.LARGE);

        // Check if getBeverage returns a deep copy
        Beverage bev1 = order.getBeverage(0);
        assertNotNull(bev1);
        assertEquals("Latte", bev1.getName());
        assertNotSame(order.getBeverages().get(0), bev1);

        Beverage bev2 = order.getBeverage(1);
        assertNotNull(bev2);
        assertEquals("Fruit Punch", bev2.getName());
        assertNotSame(order.getBeverages().get(1), bev2);

        Beverage bev3 = order.getBeverage(2);
        assertNotNull(bev3);
        assertEquals("Whiskey Sour", bev3.getName());
        assertNotSame(order.getBeverages().get(2), bev3);

        // Test when itemNo is out of bounds
        assertNull(order.getBeverage(3));
        assertNull(order.getBeverage(-1));
    }

    @Test
    public void testCalcOrderTotal() {
        Order order = new Order(4, Day.FRIDAY, new Customer("Eva Green", 35));

        order.addNewBeverage("Cappuccino", Size.LARGE, false, true);  // Price: base + large + extraSyrup
        order.addNewBeverage("Mai Tai", Size.MEDIUM);                 // Price: base + medium

        assertEquals(1.0 + 2.0 + 2.5 + 2.0, order.calcOrderTotal(), 0.001);
    }

    @Test
    public void testFindNumOfBeveType() {
        Order order = new Order(5, Day.SUNDAY, new Customer("Michael Brown", 40));

        order.addNewBeverage("Americano", Size.SMALL);                // Type: COFFEE
        order.addNewBeverage("Margarita", Size.MEDIUM);               // Type: ALCOHOL
        order.addNewBeverage("Berry Blast", Size.LARGE, 2, false);    // Type: SMOOTHIE
        order.addNewBeverage("Cappuccino", Size.LARGE, true, false);  // Type: COFFEE

        assertEquals(2, order.findNumOfBeveType(Type.COFFEE));
        assertEquals(1, order.findNumOfBeveType(Type.ALCOHOL));
        assertEquals(1, order.findNumOfBeveType(Type.SMOOTHIE));
    }

    @Test
    public void testToString() {
        Order order = new Order(6, Day.THURSDAY, new Customer("Sarah White", 30));

        order.addNewBeverage("Espresso", Size.SMALL);
        order.addNewBeverage("Pina Colada", Size.MEDIUM, false, true);

        String expectedToString = "Order{orderNumber=33668, orderTime='6', orderDay=THURSDAY, customer=Customer{name='Sarah White', age=30}, beverages=[" +
                "\n  Coffee{name='Espresso', size=SMALL, extraShot=false, extraSyrup=false, price=$1.0}," +
                "\n  Alcohol{name='Pina Colada', size=MEDIUM, offeredInWeekend=false, price=$4.0}" +
                "\n]}";

        assertEquals(expectedToString, order.toString());
    }

    @Test
    public void testGetTotalItems() {
        Order order = new Order(7, Day.TUESDAY, new Customer("Tom Black", 25));

        order.addNewBeverage("Latte", Size.LARGE, true, false);
        order.addNewBeverage("Mai Tai", Size.SMALL);
        order.addNewBeverage("Fruit Smoothie", Size.MEDIUM, 3, true);

        assertEquals(3, order.getTotalItems());
    }

}