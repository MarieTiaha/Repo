/**
 * The Size enum represents different sizes for beverages in a beverage shop system.
 *
 * <p>
 * The sizes include SMALL, MEDIUM, and LARGE. Each size may have an associated price,
 * and the getSizePrice method is provided to retrieve the price for the respective size.
 * </p>
 *
 * <p>
 * Note: The Size enum is part of a beverage shop system and is designed to work in conjunction
 * with other classes representing beverages and orders.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public enum Size {
    SMALL, MEDIUM, LARGE;
	
}
