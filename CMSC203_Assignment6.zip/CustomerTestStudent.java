import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerTestStudent {

    @Test
    public void testToString() {
        Customer customer = new Customer("John Doe", 25);
        assertEquals("Customer{name='John Doe', age=25}", customer.toString());
    }

    @Test
    public void testGetName() {
        Customer customer = new Customer("Alice Smith", 30);
        assertEquals("Alice Smith", customer.getName());
    }

    @Test
    public void testSetName() {
        Customer customer = new Customer("Bob Johnson", 28);
        customer.setName("Bob Smith");
        assertEquals("Bob Smith", customer.getName());
    }

    @Test
    public void testGetAge() {
        Customer customer = new Customer("Eva Green", 35);
        assertEquals(35, customer.getAge());
    }

    @Test
    public void testSetAge() {
        Customer customer = new Customer("Michael Brown", 40);
        customer.setAge(42);
        assertEquals(42, customer.getAge());
    }

    @Test
    public void testCopyConstructor() {
        Customer originalCustomer = new Customer("Original Customer", 50);
        Customer copiedCustomer = new Customer(originalCustomer);

        // Check if the copied customer has the same attributes
        assertEquals(originalCustomer.getName(), copiedCustomer.getName());
        assertEquals(originalCustomer.getAge(), copiedCustomer.getAge());
    }


}