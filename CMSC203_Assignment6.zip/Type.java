/**
 * The Type enum represents the different types of beverages available in a beverage shop system.
 *
 * <p>
 * The enum includes the following types: COFFEE, SMOOTHIE, and ALCOHOL. These types are used to
 * categorize beverages within the beverage shop system. The enum provides a convenient way to
 * specify the type of a beverage.
 * </p>
 *
 * <p>
 * Note: The Type enum is part of a beverage shop system and is designed to work in conjunction
 * with other classes representing beverages and orders.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public enum Type {
    /**
     * Represents the type of beverage as COFFEE.
     */
    COFFEE,

    /**
     * Represents the type of beverage as SMOOTHIE.
     */
    SMOOTHIE,

    /**
     * Represents the type of beverage as ALCOHOL.
     */
    ALCOHOL
}