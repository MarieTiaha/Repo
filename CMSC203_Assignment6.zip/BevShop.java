import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The BevShop class represents a beverage shop that processes orders for various beverages.
 *
 * <p>
 * The BevShop class implements the BevShopInterface and provides methods for managing orders,
 * processing different types of beverage orders (Coffee, Alcohol, Smoothie), calculating total
 * order prices, and tracking monthly sales.
 * </p>
 *
 * <p>
 * Note: This class uses an ArrayList to store orders and provides methods for interacting with
 * orders, beverages, and calculating sales.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public class BevShop implements BevShopInterface {

    private int numOfAlcoholDrink;
    private List<Order> orders;

    /**
     * Constructs a BevShop object with initial values.
     */
    public BevShop() {
        this.numOfAlcoholDrink = 0;
        this.orders = new ArrayList<>();
    }

    @Override
    public boolean isValidTime(int time) {
        return time >= MIN_TIME && time <= MAX_TIME;
    }

    @Override
    public int getMaxNumOfFruits() {
        return MAX_FRUIT;
    }

    @Override
    public int getMinAgeForAlcohol() {
        return MIN_AGE_FOR_ALCOHOL;
    }

    @Override
    public boolean isMaxFruit(int numOfFruits) {
        return numOfFruits > MAX_FRUIT;
    }

    @Override
    public int getMaxOrderForAlcohol() {
        return MAX_ORDER_FOR_ALCOHOL;
    }

    @Override
    public boolean isEligibleForMore() {
        return numOfAlcoholDrink < MAX_ORDER_FOR_ALCOHOL;
    }

    @Override
    public int getNumOfAlcoholDrink() {
        return numOfAlcoholDrink;
    }

    @Override
    public boolean isValidAge(int age) {
        return age >= MIN_AGE_FOR_ALCOHOL;
    }

    @Override
    public void startNewOrder(int time, Day day, String customerName, int customerAge) {
        Order order = new Order(time, day, new Customer(customerName, customerAge));
        orders.add(order);
    }

    @Override
    public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
    	Order currentOrder = getCurrentOrder();
        if (currentOrder != null) {
            currentOrder.addNewBeverage(bevName, size, extraShot, extraSyrup);
        }
    }

    @Override
    public void processAlcoholOrder(String bevName, Size size) {
    	Order currentOrder = getCurrentOrder();
        if (currentOrder != null && isEligibleForMore()) {
            currentOrder.addNewBeverage(bevName, size);
            numOfAlcoholDrink++;
        }
    }

    @Override
    public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein) {
    	Order currentOrder = getCurrentOrder();
        if (currentOrder != null) {
            currentOrder.addNewBeverage(bevName, size, numOfFruits, addProtein);
        }    
    }

    @Override
    public int findOrder(int orderNo) {
    	for (int i = 0; i < orders.size(); i++) {
            if (orders.get(i).getOrderNumber() == orderNo) {
                return i; // Order found, return the index
            }
        }
        return -1;
    }

    @Override
    public double totalOrderPrice(int orderNo) {
    	int orderIndex = findOrder(orderNo);
        if (orderIndex != -1) {
            return orders.get(orderIndex).calcOrderTotal();
        }
        return 0.0; 
    }

    @Override
    public double totalMonthlySale() {
    	double totalSale = 0.0;
        for (Order order : orders) {
            totalSale += order.calcOrderTotal();
        }
        return totalSale;
    }

    @Override
    public int totalNumOfMonthlyOrders() {
        return orders.size();
    }

    @Override
    public Order getCurrentOrder() {
    	if (!orders.isEmpty()) {
            return orders.get(orders.size() - 1);
        }
        return null;
    }

    @Override
    public Order getOrderAtIndex(int index) {
    	if (index >= 0 && index < orders.size()) {
            return orders.get(index);
        }
        return null;
    }

    @Override
    public void sortOrders() {
        Collections.sort(orders);
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("Orders:\n");
        for (Order order : orders) {
            result.append(order.toString()).append("\n");
        }
        result.append("Total Monthly Sale: $").append(totalMonthlySale());
        return result.toString();
    }
}