import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BevShopTestStudent {

    @Test
    public void testIsValidTimeValid() {
        BevShop bevShop = new BevShop();
        assertTrue(bevShop.isValidTime(10));
    }

    @Test
    public void testIsValidTimeInvalid() {
        BevShop bevShop = new BevShop();
        assertFalse(bevShop.isValidTime(5));
    }

    @Test
    public void testGetMaxNumOfFruits() {
        BevShop bevShop = new BevShop();
        assertEquals(5, bevShop.getMaxNumOfFruits());
    }

    @Test
    public void testGetMinAgeForAlcohol() {
        BevShop bevShop = new BevShop();
        assertEquals(21, bevShop.getMinAgeForAlcohol());
    }

    @Test
    public void testIsMaxFruitTrue() {
        BevShop bevShop = new BevShop();
        assertTrue(bevShop.isMaxFruit(6));
    }

    @Test
    public void testIsMaxFruitFalse() {
        BevShop bevShop = new BevShop();
        assertFalse(bevShop.isMaxFruit(4));
    }

    @Test
    public void testGetMaxOrderForAlcohol() {
        BevShop bevShop = new BevShop();
        assertEquals(3, bevShop.getMaxOrderForAlcohol());
    }

    @Test
    public void testIsEligibleForMoreTrue() {
        BevShop bevShop = new BevShop();
        bevShop.processAlcoholOrder("Whiskey", Size.MEDIUM);
        assertTrue(bevShop.isEligibleForMore());
    }

    @Test
    public void testIsEligibleForMoreFalse() {
        BevShop bevShop = new BevShop();
        bevShop.processAlcoholOrder("Vodka", Size.LARGE);
        bevShop.processAlcoholOrder("Rum", Size.SMALL);
        bevShop.processAlcoholOrder("Gin", Size.MEDIUM);
        assertTrue(bevShop.isEligibleForMore());
    }

    @Test
    public void testGetNumOfAlcoholDrink() {
        BevShop bevShop = new BevShop();
        bevShop.processAlcoholOrder("Beer", Size.SMALL);
        assertEquals(0, bevShop.getNumOfAlcoholDrink());
    }

    @Test
    public void testIsValidAgeValid() {
        BevShop bevShop = new BevShop();
        assertTrue(bevShop.isValidAge(25));
    }

    @Test
    public void testIsValidAgeInvalid() {
        BevShop bevShop = new BevShop();
        assertFalse(bevShop.isValidAge(18));
    }

    @Test
    public void testStartNewOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John Doe", 30);
        assertEquals(1, bevShop.totalNumOfMonthlyOrders());
    }

    @Test
    public void testProcessCoffeeOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(10, Day.WEDNESDAY, "Alice Smith", 28);
        bevShop.processCoffeeOrder("Latte", Size.LARGE, true, false);
        assertEquals(1, bevShop.getCurrentOrder().getTotalItems());
    }

    @Test
    public void testProcessSmoothieOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(15, Day.SATURDAY, "Bob Johnson", 22);
        bevShop.processSmoothieOrder("Berry Boost", Size.MEDIUM, 3, true);
        assertEquals(1, bevShop.getCurrentOrder().getTotalItems());
    }

    @Test
    public void testTotalOrderPrice() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(8, Day.FRIDAY, "Eva Brown", 35);
        bevShop.processAlcoholOrder("Wine", Size.MEDIUM);
        assertEquals(0.0, bevShop.totalOrderPrice(1));
    }

    @Test
    public void testTotalMonthlySale() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(14, Day.MONDAY, "Mike Davis", 40);
        bevShop.processCoffeeOrder("Espresso", Size.SMALL, false, true);
        bevShop.startNewOrder(19, Day.THURSDAY, "Sophie Miller", 27);
        bevShop.processSmoothieOrder("Tropical Twist", Size.LARGE, 2, false);
        assertEquals(7.5, bevShop.totalMonthlySale());
    }
    
    @Test
    public void testGetOrderAtIndexValid() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(10, Day.SUNDAY, "Grace Lee", 26);
        bevShop.processAlcoholOrder("Vodka", Size.LARGE);
        Order order = bevShop.getOrderAtIndex(0);
        assertNotNull(order);
        assertEquals(1, order.getTotalItems());
    }

    @Test
    public void testGetOrderAtIndexInvalid() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(16, Day.FRIDAY, "Henry Wilson", 32);
        Order order = bevShop.getOrderAtIndex(1);
        assertNull(order);
    }

    @Test
    public void testSortOrders() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(11, Day.SATURDAY, "Olivia White", 29);
        bevShop.processSmoothieOrder("Citrus Splash", Size.MEDIUM, 2, true);
        bevShop.startNewOrder(19, Day.MONDAY, "Daniel Smith", 22);
        bevShop.processCoffeeOrder("Cappuccino", Size.LARGE, false, true);
        bevShop.sortOrders();
        Order firstOrder = bevShop.getOrderAtIndex(0);
        Order secondOrder = bevShop.getOrderAtIndex(1);
        assertNotNull(firstOrder);
        assertNotNull(secondOrder);
        assertTrue(firstOrder.getOrderNumber() < secondOrder.getOrderNumber());
    }

    @Test
    public void testToString() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(14, Day.WEDNESDAY, "Emma Davis", 35);
        bevShop.processAlcoholOrder("Whiskey", Size.SMALL);
        String expected = "Orders:\n" +
                "Order{orderNumber=73162, orderTime='14', orderDay=WEDNESDAY, " +
                "customer=Customer{name='Emma Davis', age=35}, beverages=[\n" +
                "  Alcohol{name='Whiskey', size=SMALL, offeredInWeekend=false, price=$2.0}\n" +
                "]}";
        assertEquals(expected, bevShop.toString().trim());
    }

}