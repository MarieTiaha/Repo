/**
 * The Customer class represents a customer in a beverage shop.
 *
 * <p>
 * The Customer class includes properties such as name and age. It provides constructors
 * for creating a customer object with specified attributes and copying an existing customer
 * object. Additionally, it includes getters and setters for accessing and modifying customer
 * information.
 * </p>
 *
 * <p>
 * Note: This class includes a toString method for generating a string representation of the
 * customer object.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public class Customer {

    private String name;
    private int age;

    /**
     * Constructs a Customer object with the specified name and age.
     *
     * @param name The name of the customer.
     * @param age  The age of the customer.
     */
    public Customer(String name, int age) {
        this.name = name;
        this.age = age;
    }

    /**
     * Constructs a Customer object based on an existing Customer object.
     *
     * @param otherCustomer The Customer object to be copied.
     */
    public Customer(Customer otherCustomer) {
        this.name = otherCustomer.name;
        this.age = otherCustomer.age;
    }

    /**
     * Returns a string representation of the customer object.
     *
     * @return A string representation of the customer.
     */
    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    /**
     * Gets the name of the customer.
     *
     * @return The name of the customer.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the customer.
     *
     * @param name The new name for the customer.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the age of the customer.
     *
     * @return The age of the customer.
     */
    public int getAge() {
        return age;
    }

    /**
     * Sets the age of the customer.
     *
     * @param age The new age for the customer.
     */
    public void setAge(int age) {
        this.age = age;
    }
}