/**
 * The Smoothie class represents a type of beverage called Smoothie in a beverage shop system.
 *
 * <p>
 * A Smoothie has additional properties such as the number of fruits and whether protein is added.
 * The cost calculation includes the base price, size-dependent price, additional protein cost,
 * and fruit cost. The class provides methods for calculating the price, checking equality with
 * other Smoothie objects, and generating a human-readable string representation.
 * </p>
 *
 * <p>
 * Note: The Smoothie class is part of a beverage shop system and is designed to work in conjunction
 * with other classes representing beverages and orders.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public class Smoothie extends Beverage {

    private static final double PROTEIN_COST = 1.5;
    private static final double FRUIT_COST = 0.5;

    private int numberOfFruits;
    private boolean proteinAdded;

    /**
     * Constructs a Smoothie with the specified name, size, number of fruits, and protein addition.
     *
     * @param name          The name of the Smoothie.
     * @param size          The size of the Smoothie (SMALL, MEDIUM, or LARGE).
     * @param numberOfFruits The number of fruits in the Smoothie.
     * @param proteinAdded  True if protein is added, false otherwise.
     */
    public Smoothie(String name, Size size, int numberOfFruits, boolean proteinAdded) {
        super(name, Type.SMOOTHIE, size);
        this.numberOfFruits = numberOfFruits;
        this.proteinAdded = proteinAdded;
    }

    /**
     * Copy constructor for creating a deep copy of another Smoothie object.
     *
     * @param otherSmoothie The Smoothie object to copy.
     */
    public Smoothie(Smoothie otherSmoothie) {
        super(otherSmoothie); // Call the copy constructor of the superclass
        this.numberOfFruits = otherSmoothie.numberOfFruits;
        this.proteinAdded = otherSmoothie.proteinAdded;
    }

    /**
     * Calculates the price of the Smoothie based on its properties.
     *
     * @return The calculated price of the Smoothie.
     */
    @Override
    public double calcPrice() {
        double price = getBasePrice() + (getSize().ordinal() * getSizePrice());
        if (proteinAdded) {
            price += PROTEIN_COST;
        }
        
        price += numberOfFruits * FRUIT_COST;

        return price;
    }

    /**
     * Checks if this Smoothie is equal to another object.
     *
     * @param obj The object to compare for equality.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;

        Smoothie smoothie = (Smoothie) obj;

        return numberOfFruits == smoothie.numberOfFruits && proteinAdded == smoothie.proteinAdded;
    }

    /**
     * Generates a string representation of the Smoothie object.
     *
     * @return A string representation of the Smoothie.
     */
    @Override
    public String toString() {
        return "Smoothie{" +
                "name='" + getName() + '\'' +
                ", size=" + getSize() +
                ", numberOfFruits=" + numberOfFruits +
                ", proteinAdded=" + proteinAdded +
                ", price=$" + calcPrice() +
                '}';
    }

    // Getters and setters for additional instance variables
    /**
     * Gets the number of fruits in the Smoothie.
     *
     * @return The number of fruits.
     */
    public int getNumberOfFruits() {
        return numberOfFruits;
    }

    /**
     * Sets the number of fruits in the Smoothie.
     *
     * @param numberOfFruits The new number of fruits.
     */
    public void setNumberOfFruits(int numberOfFruits) {
        this.numberOfFruits = numberOfFruits;
    }

    /**
     * Checks if protein is added to the Smoothie.
     *
     * @return True if protein is added, false otherwise.
     */
    public boolean isProteinAdded() {
        return proteinAdded;
    }

    /**
     * Sets whether protein is added to the Smoothie.
     *
     * @param proteinAdded True to add protein, false otherwise.
     */
    public void setProteinAdded(boolean proteinAdded) {
        this.proteinAdded = proteinAdded;
    }
}