import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CoffeeTestStudent {

    @Test
    public void testCalcPriceWithoutExtras() {
        Coffee coffee = new Coffee("Latte", Size.MEDIUM, false, false);
        double expectedPrice = 2.0 + Size.MEDIUM.ordinal() * 1.0;
        assertEquals(expectedPrice, coffee.calcPrice(), 0.01);
    }

    @Test
    public void testCalcPriceWithExtraShot() {
        Coffee coffee = new Coffee("Espresso", Size.SMALL, true, false);
        double expectedPrice = 2.0 + Size.SMALL.ordinal() * 1.0 + 0.5;
        assertEquals(expectedPrice, coffee.calcPrice(), 0.01);
    }

    @Test
    public void testCalcPriceWithExtraSyrup() {
        Coffee coffee = new Coffee("Caramel Macchiato", Size.LARGE, false, true);
        double expectedPrice = 2.0 + Size.LARGE.ordinal() * 1.0 + 0.5;
        assertEquals(expectedPrice, coffee.calcPrice(), 0.01);
    }

    @Test
    public void testCalcPriceWithBothExtras() {
        Coffee coffee = new Coffee("Mocha", Size.MEDIUM, true, true);
        double expectedPrice = 2.0 + Size.MEDIUM.ordinal() * 1.0 + 0.5 + 0.5;
        assertEquals(expectedPrice, coffee.calcPrice(), 0.01);
    }

    @Test
    public void testEquals() {
        Coffee coffee1 = new Coffee("Latte", Size.MEDIUM, false, false);
        Coffee coffee2 = new Coffee("Latte", Size.MEDIUM, false, false);
        assertTrue(coffee1.equals(coffee2));
    }

    @Test
    public void testNotEquals() {
        Coffee coffee1 = new Coffee("Cappuccino", Size.LARGE, true, false);
        Coffee coffee2 = new Coffee("Latte", Size.MEDIUM, false, false);
        assertFalse(coffee1.equals(coffee2));
    }

    @Test
    public void testToString() {
        Coffee coffee = new Coffee("Americano", Size.SMALL, true, true);
        String expectedString = "Coffee{name='Americano', size=SMALL, extraShot=true, extraSyrup=true, price=$3.0}";
        assertEquals(expectedString, coffee.toString());
    }

    @Test
    public void testGettersAndSetters() {
        Coffee coffee = new Coffee("Flat White", Size.LARGE, false, true);
        assertFalse(coffee.isExtraShot());
        coffee.setExtraShot(true);
        assertTrue(coffee.isExtraShot());
        assertEquals("Flat White", coffee.getName());
        assertEquals(Size.LARGE, coffee.getSize());
    }

    @Test
    public void testCopyConstructor() {
        Coffee originalCoffee = new Coffee("Cappuccino", Size.MEDIUM, true, false);
        Coffee copiedCoffee = new Coffee(originalCoffee);

        assertEquals(originalCoffee, copiedCoffee);  // Check equality
        assertNotSame(originalCoffee, copiedCoffee); // Check reference difference
    }

    @Test
    public void testCopyConstructorDoesNotAffectOriginal() {
        Coffee originalCoffee = new Coffee("Cappuccino", Size.MEDIUM, true, false);
        Coffee copiedCoffee = new Coffee(originalCoffee);

        copiedCoffee.setExtraSyrup(true);

        assertFalse(originalCoffee.isExtraSyrup()); // Original should remain unchanged
        assertTrue(copiedCoffee.isExtraSyrup());
    }


}