/**
 * This abstract class represents a beverage.
 *
 * <p>
 * The Beverage class serves as the base class for different types of beverages, providing common
 * attributes such as name, type, and size. It includes methods for calculating the price of a
 * beverage, as well as overriding equals, hashCode, and toString methods.
 * </p>
 *
 * <p>
 * Note: Concrete subclasses must implement the {@code calcPrice} method.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public abstract class Beverage {

    private String name;
    private Type type;
    private Size size;
    private static final double BASE_PRICE = 2.0;
    private static final double SIZE_PRICE = 1.0;

    /**
     * Constructs a Beverage object with the specified name, type, and size.
     *
     * @param name the name of the beverage
     * @param type the type of the beverage
     * @param size the size of the beverage (SMALL, MEDIUM, LARGE)
     */
    public Beverage(String name, Type type, Size size) {
        this.name = name;
        this.type = type;
        this.size = size;
    }

    /**
     * Abstract method to calculate the price of the beverage.
     *
     * @return the calculated price of the beverage
     */
    public abstract double calcPrice();

    /**
     * Checks if two Beverage objects are equal.
     *
     * @param obj the object to compare
     * @return true if the objects are equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Beverage beverage = (Beverage) obj;

        if (!name.equals(beverage.name)) return false;
        if (type != beverage.type) return false;
        return size == beverage.size;
    }

    /**
     * Generates a hash code for the Beverage object.
     *
     * @return the hash code for the object
     */
    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + type.hashCode();
        result = 31 * result + size.hashCode();
        return result;
    }

    /**
     * Returns a string representation of the Beverage object.
     *
     * @return a string representation of the object
     */
    @Override
    public String toString() {
        return "Beverage{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", size=" + size +
                '}';
    }

    /**
     * Copy constructor for creating a deep copy of another Beverage object.
     *
     * @param otherBeverage the Beverage object to copy
     */
    public Beverage(Beverage otherBeverage) {
        this.name = otherBeverage.name;
        this.type = otherBeverage.type;
        this.size = otherBeverage.size;
    }

    // Getters and setters

    /**
     * Gets the name of the beverage.
     *
     * @return the name of the beverage
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the beverage.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the type of the beverage.
     *
     * @return the type of the beverage
     */
    public Type getType() {
        return type;
    }

    /**
     * Sets the type of the beverage.
     *
     * @param type the type to set
     */
    public void setType(Type type) {
        this.type = type;
    }

    /**
     * Gets the size of the beverage.
     *
     * @return the size of the beverage
     */
    public Size getSize() {
        return size;
    }

    /**
     * Sets the size of the beverage.
     *
     * @param size the size to set
     */
    public void setSize(Size size) {
        this.size = size;
    }

    /**
     * Gets the base price for all beverages.
     *
     * @return the base price for all beverages
     */
    public static double getBasePrice() {
        return BASE_PRICE;
    }

    /**
     * Gets the price associated with the size of the beverage.
     *
     * @return the price associated with the size of the beverage
     */
    public static double getSizePrice() {
        return SIZE_PRICE;
    }
}