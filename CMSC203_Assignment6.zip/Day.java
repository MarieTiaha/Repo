/**
 * The Day enum represents days of the week.
 *
 * <p>
 * The Day enum includes constants for each day of the week: MONDAY, TUESDAY, WEDNESDAY,
 * THURSDAY, FRIDAY, SATURDAY, and SUNDAY. It is used to represent days in various contexts
 * and provides a convenient way to work with days in a type-safe manner.
 * </p>
 *
 * <p>
 * Note: This enum is typically used in conjunction with other classes or methods that
 * require the specification of days.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public enum Day {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}
