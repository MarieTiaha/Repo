import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SmoothieTestStudent {

    @Test
    public void testCalcPrice() {
        Smoothie smallSmoothie = new Smoothie("Berry Burst", Size.SMALL, 2, true);
        assertEquals(4.5, smallSmoothie.calcPrice(), 0.001);

        Smoothie mediumSmoothie = new Smoothie("Tropical Delight", Size.MEDIUM, 3, false);
        assertEquals(4.5, mediumSmoothie.calcPrice(), 0.001);

        Smoothie largeSmoothie = new Smoothie("Mango Madness", Size.LARGE, 4, true);
        assertEquals(7.5, largeSmoothie.calcPrice(), 0.001);
    }

    @Test
    public void testEquals() {
        Smoothie smoothie1 = new Smoothie("Berry Burst", Size.SMALL, 2, true);
        Smoothie smoothie2 = new Smoothie("Berry Burst", Size.SMALL, 2, true);
        Smoothie smoothie3 = new Smoothie("Tropical Delight", Size.MEDIUM, 3, false);

        assertTrue(smoothie1.equals(smoothie2));
        assertFalse(smoothie1.equals(smoothie3));
    }

    @Test
    public void testToString() {
        Smoothie smoothie = new Smoothie("Berry Burst", Size.SMALL, 2, true);
        String expectedToString = "Smoothie{name='Berry Burst', size=SMALL, numberOfFruits=2, proteinAdded=true, price=$4.5}";
        assertEquals(expectedToString, smoothie.toString());
    }

    @Test
    public void testGettersAndSetters() {
        Smoothie smoothie = new Smoothie("Berry Burst", Size.MEDIUM, 3, false);

        assertEquals("Berry Burst", smoothie.getName());
        assertEquals(Size.MEDIUM, smoothie.getSize());
        assertEquals(3, smoothie.getNumberOfFruits());
        assertFalse(smoothie.isProteinAdded());

        smoothie.setNumberOfFruits(4);
        smoothie.setProteinAdded(true);

        assertEquals(4, smoothie.getNumberOfFruits());
        assertTrue(smoothie.isProteinAdded());
    }

}