/**
 * The Coffee class represents a coffee beverage in a beverage shop.
 *
 * <p>
 * The Coffee class extends the Beverage class and includes additional properties such as
 * extraShot and extraSyrup. It provides methods for calculating the price of the coffee
 * based on its size and additional options (extra shot, extra syrup).
 * </p>
 *
 * <p>
 * Note: This class uses the Type enum to identify the beverage type, and it includes a copy
 * constructor to create a new Coffee object based on an existing Coffee object.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public class Coffee extends Beverage {

    private static final double EXTRA_SHOT_COST = 0.5;
    private static final double EXTRA_SYRUP_COST = 0.5;

    private boolean extraShot;
    private boolean extraSyrup;
    

    /**
     * Constructs a Coffee object with the specified name, size, and additional options.
     *
     * @param name      The name of the coffee beverage.
     * @param size      The size of the coffee beverage (SMALL, MEDIUM, LARGE).
     * @param extraShot True if an extra shot is added; otherwise, false.
     * @param extraSyrup True if extra syrup is added; otherwise, false.
     */
    public Coffee(String name, Size size, boolean extraShot, boolean extraSyrup) {
        super(name, Type.COFFEE, size);
        this.extraShot = extraShot;
        this.extraSyrup = extraSyrup;
    }

    /**
     * Constructs a Coffee object based on an existing Coffee object.
     *
     * @param otherCoffee The Coffee object to be copied.
     */
    public Coffee(Coffee otherCoffee) {
        super(otherCoffee); // Call the copy constructor of the superclass
        this.extraShot = otherCoffee.extraShot;
        this.extraSyrup = otherCoffee.extraSyrup;
    }


    @Override
    public double calcPrice() {
        double price = getBasePrice() + (getSize().ordinal() * getSizePrice());
        if (extraShot) {
            price += EXTRA_SHOT_COST;
        }

        if (extraSyrup) {
            price += EXTRA_SYRUP_COST;
        }
        return price;
    }
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;

        Coffee coffee = (Coffee) obj;

        if (extraShot != coffee.extraShot) return false;
        return extraSyrup == coffee.extraSyrup;
    }

    @Override
    public String toString() {
        return "Coffee{" +
                "name='" + getName() + '\'' +
                ", size=" + getSize() +
                ", extraShot=" + extraShot +
                ", extraSyrup=" + extraSyrup +
                ", price=$" + calcPrice() +
                '}';
    }

    // Getters and setters for additional instance variables
    public boolean isExtraShot() {
        return extraShot;
    }

    public void setExtraShot(boolean extraShot) {
        this.extraShot = extraShot;
    }

    public boolean isExtraSyrup() {
        return extraSyrup;
    }

    public void setExtraSyrup(boolean extraSyrup) {
        this.extraSyrup = extraSyrup;
    }
    
}