import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 * The Order class represents a customer's order.
 *
 * <p>
 * An order consists of an order number, order time, order day, customer details, and a list
 * of beverages. Each order can include different types of beverages, such as coffee, alcohol,
 * and smoothies. The Order class implements the Comparable interface to enable sorting based
 * on the order number.
 * </p>
 *
 * <p>
 * Note: The Order class is part of a beverage shop system and is designed to work in conjunction
 * with other classes representing beverages, customers, and days.
 * </p>
 *
 * @author Marie Tiaha
 * @version 1.0
 * @since 2023-12-02
 */
public class Order implements OrderInterface, Comparable<Order> {
    private int orderNumber;
    private int orderTime;
    private Day orderDay;
    private Customer customer;
    private List<Beverage> beverages;

    // Constructor
    public Order(int i, Day orderDay, Customer customer) {
        this.orderNumber = generateOrderNumber();
        this.orderTime = i;
        this.orderDay = orderDay;
        this.customer = customer;
        this.beverages = new ArrayList<>();
    }

    // Generate a random order number within the range of 10000 and 90000
    private int generateOrderNumber() {
        Random random = new Random();
        return random.nextInt(80001) + 10000;
    }

    // Overridden method from Comparable interface
    @Override
    public int compareTo(Order otherOrder) {
        return Integer.compare(this.orderNumber, otherOrder.orderNumber);
    }

    // Overridden method from OrderInterface
    @Override
    public boolean isWeekend() {
        return orderDay == Day.SATURDAY || orderDay == Day.SUNDAY;
    }

    // Overridden method from OrderInterface
    @Override
    public Beverage getBeverage(int itemNo) {
        if (itemNo >= 0 && itemNo < beverages.size()) {
            Beverage originalBeverage = beverages.get(itemNo);
            if (originalBeverage instanceof Coffee) {
                return new Coffee((Coffee) originalBeverage);
            } else if (originalBeverage instanceof Smoothie) {
                return new Smoothie((Smoothie) originalBeverage);
            } else if (originalBeverage instanceof Alcohol) {
                return new Alcohol((Alcohol) originalBeverage);
            }
            // Handle other subclasses if needed
        }
        return null;
    }

    // Overridden method from OrderInterface
    @Override
    public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
        beverages.add(new Coffee(bevName, size, extraShot, extraSyrup)); // Assuming Coffee is a subclass of Beverage
    }

    // Overridden method from OrderInterface
    @Override
    public void addNewBeverage(String bevName, Size size) {
        beverages.add(new Alcohol(bevName, size, isWeekend())); // Assuming Alcohol is a subclass of Beverage
    }
    

    // Overridden method from OrderInterface
    @Override
    public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein) {
        beverages.add(new Smoothie(bevName, size, numOfFruits, addProtein)); // Assuming Smoothie is a subclass of Beverage
    }

    // Overridden method from OrderInterface
    @Override
    public double calcOrderTotal() {
        double total = 0.0;
        for (Beverage beverage : beverages) {
            total += beverage.calcPrice();
        }
        return total;
    }

    // Overridden method from OrderInterface
    @Override
    public int findNumOfBeveType(Type type) {
        int count = 0;
        for (Beverage beverage : beverages) {
            if (beverage.getType() == type) {
                count++;
            }
        }
        return count;
    }

    // Overridden toString method
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("Order{" +
                "orderNumber=" + orderNumber +
                ", orderTime='" + orderTime + '\'' +
                ", orderDay=" + orderDay +
                ", customer=" + customer +
                ", beverages=[");
        for (Beverage beverage : beverages) {
            result.append("\n  ").append(beverage);
        }
        result.append("\n]}");
        return result.toString();
    }

    // Getter method for customer that returns a deep copy
    public Customer getCustomer() {
        return new Customer(customer);
    }
    public int getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(int orderTime) {
        this.orderTime = orderTime;
    }

    public Day getOrderDay() {
        return orderDay;
    }

    public void setOrderDay(Day orderDay) {
        this.orderDay = orderDay;
    }

    public List<Beverage> getBeverages() {
        // Returning a copy of the list to prevent external modification
        return new ArrayList<>(beverages);
    }

    public void setBeverages(List<Beverage> beverages) {
        // Setting a new list to avoid direct reference to the original list
        this.beverages = new ArrayList<>(beverages);
    }

	public int getTotalItems() {
		return beverages.size();
	}

}