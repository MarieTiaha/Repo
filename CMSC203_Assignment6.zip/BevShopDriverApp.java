import java.util.Scanner;

public class BevShopDriverApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        BevShop bevShop = new BevShop();
        System.out.println("The current order in process can have at most 3 alcoholic beverages.");
        System.out.println("The minimum age to order an alcohol drink is 21");

        while (true) {
            System.out.println("Start please a new order:");
            bevShop.startNewOrder(1, Day.MONDAY, "", 0); // Initialize a new order
            System.out.println("The Total Price on the Order: $" + bevShop.totalMonthlySale());

            System.out.print("Would you please enter your name: ");
            String customerName = scanner.nextLine();

            System.out.print("Would you please enter your age: ");
            int customerAge = Integer.parseInt(scanner.nextLine());

            bevShop.startNewOrder(1, Day.MONDAY, customerName, customerAge);

            if (bevShop.isValidAge(customerAge)) {
                System.out.println("Your age is above 20 and you are eligible to order alcohol.");

                while (bevShop.isEligibleForMore()) {
                    System.out.println("Your current alcohol drink order is less than 4");
                    System.out.print("Would you please add an alcohol drink: ");
                    String alcoholName = scanner.nextLine();

                    bevShop.processAlcoholOrder(alcoholName, Size.MEDIUM);
                    System.out.print("The current order of drinks is " + bevShop.getNumOfAlcoholDrink() + "\n");

                    System.out.println("The Total Price on the Order is: $" + bevShop.totalOrderPrice(bevShop.getCurrentOrder().getOrderNumber()));

                    if (bevShop.isEligibleForMore()) {
                        System.out.print("Your current alcohol drink order is less than 4. Would you like to add another? (yes/no): ");
                        String addAnotherAlcohol = scanner.nextLine().toLowerCase();
                        if (!addAnotherAlcohol.equals("yes")) {
                            break;
                        }
                    }
                }
            } else {
                System.out.println("Your Age is not appropriate for an alcohol drink!!");
            }

            System.out.print("Would you like to add a COFFEE to your order? (yes/no): ");
            String addCoffee = scanner.nextLine().toLowerCase();

            if (addCoffee.equals("yes")) {
                System.out.print("Enter coffee name: ");
                String coffeeName = scanner.nextLine();
                System.out.print("Enter coffee size (SMALL, MEDIUM, LARGE): ");
                Size coffeeSize = Size.valueOf(scanner.nextLine().toUpperCase());
                System.out.print("Is extra shot needed? (true/false): ");
                boolean extraShot = Boolean.parseBoolean(scanner.nextLine());
                System.out.print("Is extra syrup needed? (true/false): ");
                boolean extraSyrup = Boolean.parseBoolean(scanner.nextLine());

                bevShop.processCoffeeOrder(coffeeName, coffeeSize, extraShot, extraSyrup);
                System.out.println("Total items on your order is " + bevShop.getCurrentOrder().getTotalItems());
                System.out.println("The Total Price on the Order is: $" + bevShop.totalOrderPrice(bevShop.getCurrentOrder().getOrderNumber()));
            }

            System.out.print("Would you like to add a SMOOTHIE to your order? (yes/no): ");
            String addSmoothie = scanner.nextLine().toLowerCase();

            if (addSmoothie.equals("yes")) {
                System.out.print("Enter smoothie name: ");
                String smoothieName = scanner.nextLine();
                System.out.print("Enter smoothie size (SMALL, MEDIUM, LARGE): ");
                Size smoothieSize = Size.valueOf(scanner.nextLine().toUpperCase());
                System.out.print("Enter number of fruits: ");
                int numOfFruits = Integer.parseInt(scanner.nextLine());

                if (numOfFruits > 4) {
                    System.out.println("You reached a Maximum number of fruits");
                    System.out.println("Total price on the second Order: $" + bevShop.totalOrderPrice(bevShop.getCurrentOrder().getOrderNumber()));
                    System.out.println("Total amount for all Orders: $" + bevShop.totalMonthlySale());
                    System.out.println("#------------------------------------#");
                    continue;
                }

                System.out.print("Is protein added? (true/false): ");
                boolean addProtein = Boolean.parseBoolean(scanner.nextLine());

                bevShop.processSmoothieOrder(smoothieName, smoothieSize, numOfFruits, addProtein);
                System.out.println("Total items on your order is " + bevShop.getCurrentOrder().getTotalItems());
                System.out.println("The Total Price on the Order is: $" + bevShop.totalOrderPrice(bevShop.getCurrentOrder().getOrderNumber()));
            } else {
                System.out.println("Total items on your order is " + bevShop.getCurrentOrder().getTotalItems());
                System.out.println("The Total Price on the Order is: $" + bevShop.totalOrderPrice(bevShop.getCurrentOrder().getOrderNumber()));
            }

            System.out.println("#------------------------------------#");
            System.out.println("Would you please start a new order");
        }
    }
}
