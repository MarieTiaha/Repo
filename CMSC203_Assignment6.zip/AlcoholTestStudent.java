import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AlcoholTestStudent {

    @Test
    public void testCalcPriceWithoutWeekend() {
        Alcohol alcohol = new Alcohol("Whiskey", Size.MEDIUM, false);
        assertEquals(3.0, alcohol.calcPrice(), 0.001);
    }

    @Test
    public void testCalcPriceWithWeekend() {
        Alcohol alcohol = new Alcohol("Wine", Size.LARGE, true);
        assertEquals(4.6, alcohol.calcPrice(), 0.001);
    }

    @Test
    public void testEquals() {
        Alcohol alcohol1 = new Alcohol("Beer", Size.SMALL, true);
        Alcohol alcohol2 = new Alcohol("Beer", Size.SMALL, true);
        assertEquals(alcohol1, alcohol2);
    }

    @Test
    public void testNotEquals() {
        Alcohol alcohol1 = new Alcohol("Vodka", Size.LARGE, false);
        Alcohol alcohol2 = new Alcohol("Whiskey", Size.MEDIUM, true);
        assertNotEquals(alcohol1, alcohol2);
    }

    @Test
    public void testToString() {
        Alcohol alcohol = new Alcohol("Tequila", Size.LARGE, true);
        String expected = "Alcohol{name='Tequila', size=LARGE, offeredInWeekend=true, price=$4.6}";
        assertEquals(expected, alcohol.toString());
    }

    @Test
    public void testGetSetOfferedInWeekend() {
        Alcohol alcohol = new Alcohol("Vodka", Size.SMALL, false);
        assertFalse(alcohol.isOfferedInWeekend());

        alcohol.setOfferedInWeekend(true);
        assertTrue(alcohol.isOfferedInWeekend());
    }
}